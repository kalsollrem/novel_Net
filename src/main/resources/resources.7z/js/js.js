$(function(){
    
    var slide_index =0;


    setInterval(function(){

        if(slide_index<2){slide_index++;}
        else{slide_index=0;}

        $(".slide-cont").animate({top:(slide_index*-280)},500)    
        $(".b-slide-cont").animate({top:(slide_index*-280)},500)    

    },3000);

});

