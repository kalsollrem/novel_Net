$(function(){
    
  //회원 가입 모달
  var sign_box = $('.sign_box');
  sign_box.css("position", "absolute");
  sign_box.css("top", Math.max(0, (($(window).height() - sign_box.outerHeight()) / 2) + $(window).scrollTop()) + "px");
  sign_box.css("left", Math.max(0, (($(window).width() - sign_box.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
  $('.sign_box').fadeIn(500);
  
  //로그인 모달
  var login_box = $('.login_box');
  login_box.css("position", "absolute");
  login_box.css("top", Math.max(0, (($(window).height() - login_box.outerHeight()) / 2) + $(window).scrollTop()) + "px");
  login_box.css("left", Math.max(0, (($(window).width() - login_box.outerWidth()) / 2) + $(window).scrollLeft()) + "px");
  $('.login_box').fadeIn(500);
  
  //검색모달
  var login_box = $('.hashtag_box');
  login_box.css("position", "absolute");
  login_box.css("top", Math.max(0, (($(window).height() - login_box.outerHeight()) / 2) + $(window).scrollTop()) + "px");
  login_box.css("left", Math.max(0, (($(window).width() - login_box.outerWidth()) / 2) + $(window).scrollLeft()) + "px");

  var tag_search = $('.tag_search');
  var switch_search = 0;

  $(tag_search).click(
    function(){
        $(".hashtag_finder").show();
        switch_search = 1;
    });
  
  $(".wrap").mouseup(
    function(){
      var LayerPopup = $(".hashtag_finder");
      if(switch_search == 1)
      {
        $(".hashtag_finder").hide();
      }
  });

  //써머노트
  $('#summernote').summernote({
    height: 600,
    lang : "ko-KR",
    focus: true, 
    toolbar: 
    [
    // [groupName, [list of button]]
    ['fontname', ['fontname']],
    ['fontsize', ['fontsize']],
    ['style', ['bold', 'italic', 'underline','strikethrough', 'clear']],
    ['color', ['forecolor','color']],
    ['para', ['paragraph']],
    ['height', ['height']],
    ['insert',['picture']],
    ],
    fontNames: ['Arial', 'Arial Black', 'Comic Sans MS', 'Courier New','맑은 고딕','궁서','굴림체','굴림','돋움체','바탕체'],
    fontSizes: ['8','9','10','11','12','14','16','18','20','22','24','28','30','36','50','72']
  });


  //글수정 기능
  const title = "";
  const memo = "";
  if(title != "" && title != null)   //제목에 값 넣기
  {
    $('#write_title').attr('value', title); 
  }
  if(memo != ""  && memo != null)  //썸머노트 본문에 글넣기
  {
    $('#summernote').summernote('editor.insertText', memo); 
  }
});
